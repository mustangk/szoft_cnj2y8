using System.Diagnostics.Metrics;
using System.Security.Permissions;

namespace Akasztófa
{
    public partial class Form1 : Form
    {
        public List<string> words = new();

        public List<char> gueses = new();

        public string word;

        public string wordMask;

        int lives = 5;


        Random rnd = new Random();
        public Form1()
        {
            InitializeComponent();
            KeyPress += Form1_KeyPress;
        }

        public void Form1_KeyPress(object? sender, KeyPressEventArgs e)
        {
            bool found = false;

            for (int i = 0; i < word.Length; i++)
            {
                if (word[i] == char.ToUpper(e.KeyChar))
                {
                    char[] tempWordMask = wordMask.ToCharArray();
                    tempWordMask[i] = e.KeyChar;
                    wordMask = new string(tempWordMask);
                    found = true;
                }
            }

            show(wordMask);
            if (word == wordMask.ToUpper()) MessageBox.Show("WIN");

            if (!found)
            {
                lives--;
                if(lives == 0)
                {
                    MessageBox.Show(word);
                }
            }
        }

        public void Form1_Load(object sender, EventArgs e)
        {


        }

        private void show(string word)
        {
            Controls.Clear();

            for (int i = 0; i < word.Length; i++)
            {
                Button b = new();
                b.Left = i * 30;
                b.Width = 30;
                Controls.Add(b);
                b.Text = word[i].ToString();

                Label l = new();
                l.Text = $"Életek száma: {lives.ToString()}";
                Controls.Add(l);
                l.Top = 30;

            }
        }

        public void button1_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog ofd = new OpenFileDialog();
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    StreamReader sr = new StreamReader(ofd.FileName);
                    while (!sr.EndOfStream)
                    {
                        words.Add(sr.ReadLine());
                    }
                    sr.Close();
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Nem támogatott fájltípus!");
            }

            word = words[rnd.Next(words.Count)].ToUpper();
            wordMask = new string('_', word.Length);
            show(wordMask);
        }
    }
}
