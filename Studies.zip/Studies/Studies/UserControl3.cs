﻿using Studies.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Studies
{
    public partial class UserControl3 : UserControl
    {
        StudiesContext context = new();
        public UserControl3()
        {
            InitializeComponent();
        }

        private void UserControl3_Load(object sender, EventArgs e)
        {
            var adatok = from l in context.Instructors

                         select new
                         {
                             Név = l.Name,
                             Cím = l.EmployementFkNavigation.Name,
                             Státusz = l.StatusFkNavigation.Name
                         };
            dataGridView1.DataSource = adatok.ToList();
        }
    }
}
